package com.midpoint.boostfps;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.ParticlesMode;

/**
 * Единая точка, которая реально применяет снижение качества графики.
 *
 * ВАЖНО: здесь НЕТ ни одного миксина — мы только программно переключаем
 * штатные (официальные) настройки игры, ровно так же, как если бы игрок
 * сам зашёл в Options -> Video и подвигал слайдеры. Это гарантирует, что
 * мод не сломается из-за смены внутренних (немаппленных / обфусцированных)
 * методов рендер-пайплайна между сборками/версиями — используются только
 * стабильные публичные методы GameOptions.
 *
 * Уровни (0..3):
 *  0 — обычное качество (базовые настройки игрока без изменений)
 *  1 — лёгкое снижение: частицы уменьшены
 *  2 — среднее: + графика FAST, дальность сущностей снижена
 *  3 — сильное: + дальность прорисовки снижена
 *
 * Итоговый применяемый уровень = максимум из того, что просят ThermalGuard
 * и Combat Boost одновременно (если оба активны — побеждает более сильное
 * снижение).
 */
public class QualityController {

    public static final QualityController INSTANCE = new QualityController();

    private boolean baselineCaptured = false;
    private ParticlesMode baselineParticles;
    private GraphicsMode baselineGraphicsMode;
    private double baselineEntityDistanceScaling;
    private int baselineViewDistance;

    private int currentAppliedLevel = -1; // -1 = ещё ни разу не применяли

    private QualityController() {
    }

    /** Вызывается каждый клиентский тик с итоговым желаемым уровнем (0..3). */
    public void apply(int level) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.options == null) {
            return;
        }

        level = Math.max(0, Math.min(3, level));

        if (level == 0) {
            if (currentAppliedLevel != 0 && baselineCaptured) {
                restoreBaseline(client.options);
            }
            currentAppliedLevel = 0;
            return;
        }

        if (!baselineCaptured) {
            captureBaseline(client.options);
        }

        if (level == currentAppliedLevel) {
            return; // ничего не изменилось — не дёргаем настройки лишний раз
        }

        GameOptions options = client.options;

        // Уровень 1: слегка урезаем частицы
        ParticlesMode targetParticles = baselineParticles;
        if (level >= 1) {
            targetParticles = ParticlesMode.MINIMAL;
        }
        options.getParticles().setValue(targetParticles);

        // Уровень 2+: переключаем графику на FAST и уменьшаем дальность сущностей
        GraphicsMode targetGraphics = baselineGraphicsMode;
        double targetEntityScaling = baselineEntityDistanceScaling;
        if (level >= 2) {
            targetGraphics = GraphicsMode.FAST;
            targetEntityScaling = Math.max(0.5, baselineEntityDistanceScaling * 0.7);
        }
        options.getGraphicsMode().setValue(targetGraphics);
        options.getEntityDistanceScaling().setValue(targetEntityScaling);

        // Уровень 3: дополнительно немного урезаем дальность прорисовки
        int targetViewDistance = baselineViewDistance;
        if (level >= 3) {
            targetViewDistance = Math.max(4, baselineViewDistance - 4);
        }
        options.getViewDistance().setValue(targetViewDistance);

        currentAppliedLevel = level;
    }

    private void captureBaseline(GameOptions options) {
        baselineParticles = options.getParticles().getValue();
        baselineGraphicsMode = options.getGraphicsMode().getValue();
        baselineEntityDistanceScaling = options.getEntityDistanceScaling().getValue();
        baselineViewDistance = options.getViewDistance().getValue();
        baselineCaptured = true;
    }

    private void restoreBaseline(GameOptions options) {
        options.getParticles().setValue(baselineParticles);
        options.getGraphicsMode().setValue(baselineGraphicsMode);
        options.getEntityDistanceScaling().setValue(baselineEntityDistanceScaling);
        options.getViewDistance().setValue(baselineViewDistance);
    }

    /** Для отображения текущего состояния (например, в будущем HUD-виджете). */
    public int getCurrentAppliedLevel() {
        return Math.max(0, currentAppliedLevel);
    }
}
