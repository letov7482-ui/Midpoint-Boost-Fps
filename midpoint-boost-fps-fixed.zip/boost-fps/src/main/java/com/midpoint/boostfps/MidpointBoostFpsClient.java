package com.midpoint.boostfps;

import me.shedaniel.autoconfig.AutoConfig;
import me.shedaniel.autoconfig.serializer.GsonConfigSerializer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.network.ClientPlayerEntity;

/**
 * Клиентская точка входа MidpointBoostFPS.
 *
 * Здесь объединяются обе механики:
 *  - ThermalGuard (ThermalGuardManager) — следит за деградацией FPS каждый
 *    отрисованный кадр (через официальный HudRenderCallback из Fabric API).
 *  - Combat Boost (CombatStateManager) — следит за боем каждый игровой тик.
 *
 * Итоговый уровень снижения качества = максимум из того, что просят обе
 * механики, и применяется через QualityController (только официальные
 * настройки игры, без единого миксина).
 */
public class MidpointBoostFpsClient implements ClientModInitializer {

    public static final String MOD_ID = "midpoint-boost-fps";

    @Override
    public void onInitializeClient() {
        AutoConfig.register(ModConfig.class, GsonConfigSerializer::new);

        // Раз в отрисованный кадр — обновляем ThermalGuard.
        // HudRenderCallback — официальное, документированное событие Fabric API,
        // которое надёжно вызывается ровно один раз на каждый отображённый кадр.
        HudRenderCallback.EVENT.register((drawContext, tickCounter) ->
                ThermalGuardManager.INSTANCE.onFrameRendered());

        // Раз в игровой тик — обновляем состояние боя и применяем итоговый уровень качества.
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            ClientPlayerEntity player = client.player;
            CombatStateManager.INSTANCE.update(player);

            ModConfig config = getConfig();
            if (config == null || !config.globalEnabled) {
                QualityController.INSTANCE.apply(0);
                return;
            }

            int thermalLevel = config.enableThermalGuard
                    ? ThermalGuardManager.INSTANCE.getRequestedLevel()
                    : 0;

            int combatLevel = (config.enableCombatBoost && CombatStateManager.INSTANCE.isInCombat())
                    ? config.combatBoostLevel
                    : 0;

            int effectiveLevel = Math.max(thermalLevel, combatLevel);
            QualityController.INSTANCE.apply(effectiveLevel);
        });
    }

    public static ModConfig getConfig() {
        return AutoConfig.getConfigHolder(ModConfig.class).getConfig();
    }
}
