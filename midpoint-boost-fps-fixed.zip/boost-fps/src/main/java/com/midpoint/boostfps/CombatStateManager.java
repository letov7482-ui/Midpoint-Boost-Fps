package com.midpoint.boostfps;

import net.minecraft.client.network.ClientPlayerEntity;

/**
 * Отслеживает, находится ли локальный игрок "в бою" — используется механикой
 * Combat Boost. Логика простая и безопасная: сравниваем здоровье игрока
 * на этом тике с предыдущим — если оно упало, игрок получил урон, и мы
 * запускаем/продлеваем таймер боя на 10 секунд.
 */
public class CombatStateManager {

    public static final CombatStateManager INSTANCE = new CombatStateManager();

    private static final int COMBAT_DURATION_TICKS = 20 * 10; // 10 секунд

    private float lastKnownHealth = -1.0F;
    private int combatTicksLeft = 0;

    private CombatStateManager() {
    }

    /** Вызывается каждый клиентский тик. */
    public void update(ClientPlayerEntity player) {
        if (player == null) {
            lastKnownHealth = -1.0F;
            combatTicksLeft = 0;
            return;
        }

        float currentHealth = player.getHealth();

        if (lastKnownHealth < 0.0F) {
            lastKnownHealth = currentHealth;
        } else if (currentHealth < lastKnownHealth) {
            combatTicksLeft = COMBAT_DURATION_TICKS;
        }

        lastKnownHealth = currentHealth;

        if (combatTicksLeft > 0) {
            combatTicksLeft--;
        }
    }

    public boolean isInCombat() {
        return combatTicksLeft > 0;
    }

    public void reset() {
        lastKnownHealth = -1.0F;
        combatTicksLeft = 0;
    }
}
