package com.midpoint.boostfps;

import me.shedaniel.autoconfig.ConfigData;
import me.shedaniel.autoconfig.annotation.Config;
import me.shedaniel.autoconfig.annotation.ConfigEntry;

/**
 * Конфигурация MidpointBoostFPS.
 *
 * Все поля разбиты по категориям (вкладкам в экране настроек ModMenu):
 *  - general — общий выключатель мода;
 *  - thermal — механика ThermalGuard;
 *  - combat  — механика Combat Boost.
 *
 * Название и подсказка (тултип) каждого поля берутся из lang-файлов
 * (assets/midpoint-boost-fps/lang/ru_ru.json и en_us.json), поэтому в самом
 * экране настроек у каждого переключателя будет понятное русское название
 * и текст-подсказка, что именно он делает.
 */
@Config(name = "midpoint-boost-fps")
public class ModConfig implements ConfigData {

    // ---------------------------------------------------------------
    // ОБЩИЕ НАСТРОЙКИ
    // ---------------------------------------------------------------

    @ConfigEntry.Category("general")
    @ConfigEntry.Gui.Tooltip
    public boolean globalEnabled = true;

    // ---------------------------------------------------------------
    // THERMAL GUARD — адаптивная защита от просадок FPS / троттлинга
    // ---------------------------------------------------------------

    @ConfigEntry.Category("thermal")
    @ConfigEntry.Gui.Tooltip
    public boolean enableThermalGuard = true;

    @ConfigEntry.Category("thermal")
    @ConfigEntry.Gui.Tooltip
    @ConfigEntry.BoundedDiscrete(min = 1, max = 10)
    public int thermalSensitivity = 5;

    // ---------------------------------------------------------------
    // COMBAT BOOST — снижение качества графики во время боя
    // ---------------------------------------------------------------

    @ConfigEntry.Category("combat")
    @ConfigEntry.Gui.Tooltip
    public boolean enableCombatBoost = true;

    @ConfigEntry.Category("combat")
    @ConfigEntry.Gui.Tooltip
    @ConfigEntry.BoundedDiscrete(min = 1, max = 3)
    public int combatBoostLevel = 2;
}
