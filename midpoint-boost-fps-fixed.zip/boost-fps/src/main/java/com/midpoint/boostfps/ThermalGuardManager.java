package com.midpoint.boostfps;

/**
 * ThermalGuard — адаптивная защита от просадок FPS (в т.ч. из-за теплового
 * троттлинга телефона/слабого железа).
 *
 * Как это работает:
 *  1) Каждый отрисованный кадр (см. регистрацию HudRenderCallback в
 *     MidpointBoostFpsClient) сюда прилетает вызов onFrameRendered().
 *  2) Мы считаем текущий FPS через скользящее окно ~30 последних кадров.
 *  3) Отдельно храним "эталонный" (лучший недавно достигнутый) FPS —
 *     он медленно "подтягивается" вверх, когда игра работает быстро,
 *     и служит ориентиром "как быстро вообще может работать игра сейчас".
 *  4) Если текущий FPS устойчиво (не разово!) проседает ниже эталонного
 *     больше, чем разрешает чувствительность (thermalSensitivity) — мы
 *     повышаем уровень "просьбы снизить качество" (requestedLevel).
 *  5) Как только FPS восстанавливается — requestedLevel плавно снижается
 *     обратно к 0 (обычное качество).
 *
 * Итоговый requestedLevel (0..3) передаётся в QualityController, который
 * уже применяет реальные изменения графики через официальные настройки игры.
 */
public class ThermalGuardManager {

    public static final ThermalGuardManager INSTANCE = new ThermalGuardManager();

    // Сколько кадров держим в скользящем окне для расчёта текущего FPS
    private static final int FRAME_WINDOW = 30;

    private final long[] frameTimestamps = new long[FRAME_WINDOW];
    private int frameIndex = 0;
    private int framesCollected = 0;

    private double currentFps = 60.0;
    private double referenceFps = 60.0;

    // Сколько секунд подряд FPS должен быть просажен/восстановлен,
    // прежде чем мы среагируем — защита от разовых микро-лагов (например,
    // при заходе в новый чанк), а не от устойчивой деградации.
    private double degradedSeconds = 0.0;
    private double recoveredSeconds = 0.0;

    private int requestedLevel = 0;
    private long lastUpdateNanos = -1;

    private ThermalGuardManager() {
    }

    /**
     * Вызывается один раз за отрисованный кадр (см. HudRenderCallback).
     */
    public void onFrameRendered() {
        long now = System.nanoTime();
        frameTimestamps[frameIndex] = now;
        frameIndex = (frameIndex + 1) % FRAME_WINDOW;
        if (framesCollected < FRAME_WINDOW) {
            framesCollected++;
        }

        if (framesCollected >= 2) {
            // Индекс самого старого кадра в кольцевом буфере
            int oldestIndex = framesCollected < FRAME_WINDOW ? 0 : frameIndex;
            long oldest = frameTimestamps[oldestIndex];
            double elapsedSeconds = (now - oldest) / 1_000_000_000.0;
            int framesInWindow = framesCollected - 1;
            if (elapsedSeconds > 0.001) {
                currentFps = framesInWindow / elapsedSeconds;
            }
        }

        // "Эталонный" FPS медленно тянется к текущему, но растёт быстрее, чем падает —
        // так разовый лаг не собьёт эталон, а устойчивый рост производительности
        // (например, вышли из тяжёлой зоны) со временем поднимет планку.
        if (currentFps > referenceFps) {
            referenceFps += (currentFps - referenceFps) * 0.01;
        } else {
            referenceFps += (currentFps - referenceFps) * 0.002;
        }

        updateDecision(now);
    }

    private void updateDecision(long now) {
        if (lastUpdateNanos < 0) {
            lastUpdateNanos = now;
            return;
        }
        double deltaSeconds = (now - lastUpdateNanos) / 1_000_000_000.0;
        lastUpdateNanos = now;
        // Защита от аномальных скачков времени (например, после паузы/загрузки)
        deltaSeconds = Math.min(deltaSeconds, 1.0);

        ModConfig config = MidpointBoostFpsClient.getConfig();
        if (config == null || !config.globalEnabled || !config.enableThermalGuard) {
            requestedLevel = 0;
            degradedSeconds = 0;
            recoveredSeconds = 0;
            return;
        }

        // sensitivity 1..10 -> порог допустимой просадки FPS: чем выше
        // чувствительность, тем меньшая просадка уже считается проблемой,
        // и тем быстрее мод реагирует.
        int sensitivity = Math.max(1, Math.min(10, config.thermalSensitivity));
        double dropThreshold = 0.32 - (sensitivity - 1) * 0.02; // 0.32 .. 0.14
        double reactionSeconds = 6.0 - (sensitivity - 1) * 0.5; // 6.0 .. 1.5 сек

        boolean isDegraded = referenceFps > 10 && currentFps < referenceFps * (1.0 - dropThreshold);
        boolean isRecovered = currentFps >= referenceFps * 0.95;

        if (isDegraded) {
            degradedSeconds += deltaSeconds;
            recoveredSeconds = 0;
        } else if (isRecovered) {
            recoveredSeconds += deltaSeconds;
            degradedSeconds = 0;
        } else {
            // Промежуточное состояние — не копим ни деградацию, ни восстановление
            degradedSeconds = Math.max(0, degradedSeconds - deltaSeconds);
            recoveredSeconds = Math.max(0, recoveredSeconds - deltaSeconds);
        }

        if (degradedSeconds >= reactionSeconds) {
            requestedLevel = Math.min(3, requestedLevel + 1);
            degradedSeconds = 0;
        } else if (recoveredSeconds >= reactionSeconds) {
            requestedLevel = Math.max(0, requestedLevel - 1);
            recoveredSeconds = 0;
        }
    }

    /**
     * @return сколько "ступеней" снижения качества (0..3) просит ThermalGuard прямо сейчас
     */
    public int getRequestedLevel() {
        return requestedLevel;
    }

    public double getCurrentFps() {
        return currentFps;
    }

    public double getReferenceFps() {
        return referenceFps;
    }
}
